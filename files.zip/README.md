# Bumble Photo Slideshow — Angular Frontend

Angular 17 frontend for the Bumble Photo Slideshow BFF.
Uses standalone components, Angular Signals, and CDK Drag-and-Drop.

## Stack

- **Angular 17** — standalone components, `@angular/core` signals
- **Angular CDK** — drag-and-drop photo reordering
- **RxJS 7** — HTTP streams and upload progress events
- **Angular Animations** — slide-in panels, transitions
- **TypeScript strict mode** — 100% typed against OpenAPI models

## Project structure

```
src/app/
├── core/
│   ├── models/api.models.ts        ← Typed 1:1 with OpenAPI schemas
│   ├── services/
│   │   ├── auth.service.ts         ← JWT token management
│   │   ├── photo-api.service.ts    ← BFF HTTP client (all endpoints)
│   │   ├── profile-api.service.ts  ← Profile + health endpoints
│   │   └── slideshow.store.ts      ← Signals-based state store
│   └── interceptors/
│       └── auth.interceptor.ts     ← Attaches Bearer token to all requests
├── features/
│   ├── slideshow/
│   │   ├── slideshow.component.ts  ← Main viewer (keyboard, touch swipe)
│   │   └── photo-grid.component.ts ← Drag-to-reorder thumbnail grid
│   └── upload/
│       └── upload-panel.component.ts ← Drag-and-drop upload + progress
└── shared/
    └── pipes/file-size.pipe.ts
```

## Running locally

### Prerequisites
- Node.js 20+
- BFF running at `http://localhost:8080` (see `../bumble-bff/README.md`)

### Install and start
```bash
npm install
npm start
# → http://localhost:4200
```

### Run tests
```bash
npm test
```

### Build for production
```bash
npm run build:prod
# → dist/bumble-slideshow/
```

## Upload flow

The app implements the BFF's 2-step upload:

1. `POST /v1/profiles/{id}/photos` — BFF creates DB record, returns signed GCS PUT URL
2. `PUT <signedUploadUrl>` — client PUTs image bytes directly to GCS (progress tracked via `HttpEventType.UploadProgress`)
3. After upload, `loadProfile()` is called to refresh the photo list with a fresh signed view URL

## Keyboard & touch navigation

| Input | Action |
|-------|--------|
| `→` arrow key | Next photo |
| `←` arrow key | Previous photo |
| Swipe left (touch) | Next photo |
| Swipe right (touch) | Previous photo |
| Click dot | Go to photo |

## Photo reordering

Drag thumbnails in the grid below the slideshow. On drop:
1. Optimistic update (instant UI feedback)
2. `PUT /v1/profiles/{id}/photos/order` — persists new order to BFF
3. On error, optimistic update is rolled back

## Environment configuration

| File | Used when |
|------|-----------|
| `environment.dev.ts` | `ng serve` / `ng build --configuration development` |
| `environment.prod.ts` | `ng build` (default = production) |

Set `apiBaseUrl` to your Cloud Run URL for production:
```bash
ng build --configuration production
```
Or set it at build time via Angular's `fileReplacements` in `angular.json`.
